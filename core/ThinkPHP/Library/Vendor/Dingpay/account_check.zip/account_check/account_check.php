﻿<?php
/**
*实名认证接口
*/

///////////////////////////////////////////////////////////////////////////////////
	
	/**
		商户私钥，由openssl工具生成，生成方法请参考《密钥对的生成与使用文档》，格式上是要求换行的
   */

$priKey='-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDF8xn+fPEe+mMMEWX1B1/6b0QNPnZD/4At2H6NXSZsoa8zdYRL
GfM/IzLdkci560meyqY7LQuLJkvXH1VKuDeE3Rbsir/y8DUzUL6XF9fEuzhPGWYg
LRJzRkOe3kKpdOv/9I4IJAeMuZoSG54Hg9erJlLYmGOYMHoC6qe7EEGckQIDAQAB
AoGBAIhHUGsLG3mHSi9hvv7NX/9rIL+5c/Rmb5mghafPLIf3XEYiLr0BlZyvH/K4
zidpXBrtSzpMTbkz2Vy2HqM9ZkJkCPw5XMPW9wzcE1rmmDRlfpYyaX5zjtyBV2BZ
b0WSGwTayDpaBO8x5CMla3cHkpoWRn7mdIB5Kg61ChHQ6bkRAkEA9+MSRYkijcEy
3zthPrPdR/wficDWNsAzwWuDoEIXYZYTA8PE3wjjVOnXWvwEyKaRCa03y9fNMQb5
CmMF4J1/lQJBAMxtoNlDSiudm/yPq5qy1E1vjxNGnvTpkfzY9ZGUqLH2d+UofPuc
4HKwjX3Xk0R9lQx0wglyf8ra6T63lnTZGg0CQHckSWToe5YcVKIcfSnQ8zsk/9eK
uqrICFgfn70H5wr9QZheoKH+OJ1YYyyU0ovKGw3Glnm/+BxnWI1YeLuzl10CQFrF
YuKVyl1LgnPGp3/tX+9yValNdk9xVu1auM+HntBGjD4omDZxFghW9Lyn+DA1QvVg
8reXK787LM44XopLzBECQQDHw1KYEday626kv1Q+WMzdrMdIdY3SRXWoNb05R07c
kYIp+XfK+xG9BtT4mjiG6f5I+GP6xxOfQ+4wYPSGnyFR
-----END RSA PRIVATE KEY-----';

	
	$priKey= openssl_get_privatekey($priKey);
	
	
	//接口类型，必填，固定值identity_check
   $service_type = "account_check";
   
   //商家号，必填
   $merchant_code="1118004517";
   
   //流水号，必填，商家自己设置
   $merchant_serial_no ="789";
   
   //身份证号码，必填
   $id_no = "441622199207100012";
   
   //银行卡号，必填
   $card_no="6212264000014203646";
   
    //银行卡户名，必填
   $card_name="黄豪";
   
    //银行预留手机号，必填
   $mobile_no="15989882747";
   
   //接口版本，固定值
   $interface_version = "V3.0";
   
   //签名类型(加密方式)，必填，RSA-S或者RSA
   $sign_type="RSA-S";
   
   
   /**
		参数组装，并且加密
   */
	$signStr= "";
	$signStr = $signStr."card_name=".$card_name."&";	
	$signStr = $signStr."card_no=".$card_no."&";	
	$signStr = $signStr."id_no=".$id_no."&";	
	$signStr = $signStr."interface_version=".$interface_version."&";	
	$signStr = $signStr."merchant_code=".$merchant_code."&";	
	$signStr = $signStr."merchant_serial_no=".$merchant_serial_no."&";	
	$signStr = $signStr."mobile_no=".$mobile_no."&";		
	$signStr = $signStr."service_type=".$service_type;	
	
	/**
		调用openssl_sign函数获取到参数sign的值,需要在php_ini文件里打开php_openssl插件
   */
	
	openssl_sign($signStr,$sign_info,$priKey,OPENSSL_ALGO_MD5);
	
	$sign = base64_encode($sign_info);

?>
<!-- 以post方式提交所有接口参数到智付网关https://identiy.dinpay.com/accountCheck -->
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</head>	
	<body onLoad="document.dinpayForm.submit();">
		<form name="dinpayForm" method="post" action="https://identiy.dinpay.com/accountCheck" target="_self">
			<input type="hidden" name="sign"		  value="<?php echo $sign?>" />
			<input type="hidden" name="merchant_code" value="<?php echo $merchant_code?>" />
			<input type="hidden" name="merchant_serial_no"     value="<?php echo $merchant_serial_no?>"/>
			<input type="hidden" name="sign_type"      value="<?php echo $sign_type?>"/>
			<input type="hidden" name="card_name"  value="<?php echo $card_name?>"/>
			<input type="hidden" name="card_no"  value="<?php echo $card_no?>"/>
			<input type="hidden" name="mobile_no"  value="<?php echo $mobile_no?>"/>
			<input type="hidden" name="service_type"  value="<?php echo $service_type?>"/>
			<input type="hidden" name="interface_version" value="<?php echo $interface_version?>"/>
			<input type="hidden" name="id_no"    value="<?php echo $id_no?>">
			</form>
	</body>
</html>